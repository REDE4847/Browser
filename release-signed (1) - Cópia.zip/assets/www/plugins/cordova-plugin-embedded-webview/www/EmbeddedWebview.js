cordova.define("cordova-plugin-embedded-webview.EmbeddedWebview", function(require, exports, module) {
(function () {
    var exec = require('cordova/exec');
    var channel = require('cordova/channel');

    var channels = {
        'loadstart': channel.create('loadstart'),
        'loadstop': channel.create('loadstop'),
        'loaderror': channel.create('loaderror'),
        'exit': channel.create('exit')
    };

    function EmbeddedWebview() {}

    EmbeddedWebview.prototype = {
        _eventHandler: function (event) {
            console.log('Event fired', event);
            if (event && (event.type in channels)) {
                channels[event.type].fire(event);
            }
        },
        create: function(url, marginLeft, marginRight, marginTop, marginBottom, visible = true) {
            return exec(this._eventHandler, this._eventHandler, "EmbeddedWebview", "create", [url, marginLeft, marginRight, marginTop, marginBottom, visible]);
        },
        resize: function(newWidth, newHeight) {
            exec(null, null, "EmbeddedWebview", "resize", [newWidth, newHeight]);
        },
        show: function() {
            exec(null, null, "EmbeddedWebview", "show", []);
        },
        hide: function() {
            exec(null, null, "EmbeddedWebview", "hide", []);
        },
        sendToBack: function() {
            exec(null, null, "EmbeddedWebview", "sendToBack", []);
        },
        bringToFront: function() {
            exec(null, null, "EmbeddedWebview", "bringToFront", []);
        },
        load: function(url) {
            exec(null, null, "EmbeddedWebview", "load", [url]);
        },
        setMargins: function(marginLeft, marginRight, marginTop, marginBottom) {
            exec(null, null, "EmbeddedWebview", "setMargins", [marginLeft, marginRight, marginTop, marginBottom]);
        },
        resizeViews: function() {
            exec(null, null, "EmbeddedWebview", "resizeViews", []);
        },
        menuOpen: function(menuWidth, slideDirection) {
            exec(null, null, "EmbeddedWebview", "menuSlide", [menuWidth, slideDirection]);
        },
        menuClose: function(slideDirection) {
           exec(null, null, "EmbeddedWebview", "menuSlide", [0, slideDirection]);
        },
        canGoBack: function(cb) {
            return exec(cb, null, "EmbeddedWebview", "canGoBack", []);
        },
        hideCloseButton: function() {
            exec(null, null, "EmbeddedWebview", "hideCloseButton", []);
        },
        showCloseButton: function() {
            exec(null, null, "EmbeddedWebview", "showCloseButton", []);
        },
        setCloseButtonText: function(text) {
            exec(null, null, "EmbeddedWebview", "setCloseButtonText", [text]);
        },
	    requestFocus: function() {
            exec(null, null, "EmbeddedWebview", "requestFocus", []);
        },
        setBm: function(flag) {
            exec(null, null, "EmbeddedWebview", "setBm", [flag]);
        },
        hideToolbar: function() {
            exec(null, null, "EmbeddedWebview", "hideToolbar", []);
        },
        showToolbar: function() {
            exec(null, null, "EmbeddedWebview", "showToolbar", []);
        },
        addEventListener: function(eventName, cb) {
            if (eventName in channels) {
                channels[eventName].subscribe(cb);
            }
        },
        removeEventListener: function(eventName, cb) {
            if (eventName in channels) {
                channels[eventName].unsubscribe(cb);
            }
        },
        executeScript: function (injectDetails, cb) {
            if (injectDetails.code) {
                exec(cb, null, 'EmbeddedWebview', 'injectScriptCode', [injectDetails.code, !!cb]);
            } else if (injectDetails.file) {
                exec(cb, null, 'EmbeddedWebview', 'injectScriptFile', [injectDetails.file, !!cb]);
            } else {
                throw new Error('executeScript requires exactly one of code or file to be specified');
            }
        },
        insertCSS: function (injectDetails, cb) {
            if (injectDetails.code) {
                exec(cb, null, 'EmbeddedWebview', 'injectStyleCode', [injectDetails.code, !!cb]);
            } else if (injectDetails.file) {
                exec(cb, null, 'EmbeddedWebview', 'injectStyleFile', [injectDetails.file, !!cb]);
            } else {
                throw new Error('insertCSS requires exactly one of code or file to be specified');
            }
        }
    };

    module.exports = new EmbeddedWebview();

    document.addEventListener("resume", function() {
        module.exports.requestFocus();
    }, false);

})();

});
