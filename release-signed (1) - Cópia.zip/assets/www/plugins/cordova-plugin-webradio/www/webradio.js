cordova.define("cordova-plugin-webradio.WebRadio", function(require, exports, module) {
var argscheck = require('cordova/argscheck'),
    utils = require('cordova/utils'),
    exec = require('cordova/exec');

var WebRadio = {};
               
WebRadio.create = function(url, successCb, errorCb, statusCb) {
    this.url = url;
    this.id = utils.createUUID();
    this.successCb = successCb;
    this.errorCb = errorCb;
    this.statusCb = statusCb;
               
    exec(null, this.errorCb, 'WebRadio', 'create', [this.url]);
}

WebRadio.MEDIA_STATE = 1;
WebRadio.MEDIA_DURATION = 2;
WebRadio.MEDIA_POSITION = 3;
WebRadio.MEDIA_ERROR = 9;

WebRadio.MEDIA_NONE = 0;
WebRadio.MEDIA_STARTING = 1;
WebRadio.MEDIA_RUNNING = 2;
WebRadio.MEDIA_PAUSED = 3;
WebRadio.MEDIA_STOPPED = 4;
WebRadio.MEDIA_MSG = ['None', 'Starting', 'Running', 'Paused', 'Stopped'];

WebRadio.play = function() {
  exec(null, this.errorCb, 'WebRadio', 'play', []);
};

WebRadio.pause = function() {
  exec(null, this.errorCb, 'WebRadio', 'pause', []);
};

WebRadio.stop = function() {
  exec(null, this.errorCb, 'WebRadio', 'stop', []);
};

WebRadio.setVolume = function(volume) {
  exec(null, null, 'WebRadio', 'setVolume', [volume]);
};

WebRadio.getVolume = function(volume) {
  exec(null, null, 'WebRadio', 'setVolume', [volume]);
};

WebRadio.release = function() {
  exec(null, this.errorCb, 'WebRadio', 'release', []);
};

WebRadio.getState = function(successCb, errorCb) {
  exec(successCb, errorCb, 'WebRadio', 'getState', []);
}

WebRadio.ExoPlayer = {
    show: function (parameters, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'show', [parameters]);
    },
    setStream: function (url, controller, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'setStream', [url, controller]);
    },
    playPause: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'playPause', []);
    },
    stop: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'stop', []);
    },
    setVolume: function (volume, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'setVolume', [volume]);
    },
    getVolume: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'getVolume', []);
    },
    getState: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'getState', []);
    },
    canPostNotifications: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'canPostNotifications', []);
    },
    openNotificationSettings: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'openNotificationSettings', []);
    },
    close: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'WebRadio', 'close', []);
    }
};

WebRadio.onStatus = function(id, msgType, value) {
    var media = this;

    if (media) {
        switch(msgType) {
            case WebRadio.MEDIA_STATE :
                
                if (media.statusCb) {
                    media.statusCb(value);
                }

                if (value == WebRadio.MEDIA_STOPPED) {
                    if (media.successCb) {
                        media.successCb();
                    }
                }
                break;

            case WebRadio.MEDIA_ERROR :
                if (media.errorCb) {
                    media.errorCb(value);
                }
                break;

            default :
                if (console.error) {
                    console.error('Unhandled WebRadio.onStatus :: ' + msgType);
                }
                break;
        }
    } else if (console.error) {
        console.error('Received WebRadio.onStatus callback for unknown media :: ' + id);
    }

};
               
module.exports = WebRadio;

});
